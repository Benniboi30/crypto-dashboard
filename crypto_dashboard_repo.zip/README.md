# Crypto Dashboard

## 🔥 Features
- Streamlit dashboard for crypto tracking and auto-trading
- Integrated with Binance and Coinbase
- Backtesting interface
- Telegram alerts
- Secure environment configuration

## 🚀 Setup
1. Clone the repo
2. Rename `.env.template` to `.env` and add your API keys
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the dashboard locally:
   ```bash
   streamlit run dashboard/dashboard.py
   ```

## 🌐 Deploy to Render
1. Push to GitHub
2. Go to [https://render.com](https://render.com) and create a new Web Service
3. Add environment variables in the Render UI (match your .env keys)
4. Done! Access the dashboard from your iPhone or browser

## ⚠️ Never share your real `.env` file publicly.
