import streamlit as st

st.set_page_config(page_title="Crypto Trading Dashboard", layout="wide")
st.title("📊 Automated Crypto Trading Dashboard")

st.write("Welcome to your private dashboard. Strategies, live trades, and more coming soon.")

# You will add live strategy toggles, portfolio data, and logs here
